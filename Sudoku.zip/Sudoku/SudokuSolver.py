
with open ("matrix.txt") as file:
    matrix = file.read()
board = []
for i in range(9):
    board.append([])
    
index = 0   
for string in matrix:
    for number in string:
        if number not in (",", "\n", "[", "]"):
            board[index].append(int(number))
        if number == "\n":
            index+=1
'''
board = [
        [7, 8, 0, 4, 0, 0, 1, 2, 0],
        [6, 0, 0, 0, 7, 5, 0, 0, 9],
        [0, 0, 0, 6, 0, 1, 0, 7, 8],
        [0, 0, 7, 0, 4, 0, 2, 6, 0],
        [0, 0, 1, 0, 5, 0, 9, 3, 0],
        [9, 0, 4, 0, 6, 0, 0, 0, 5],
        [0, 7, 0, 3, 0, 0, 0, 1, 2],
        [1, 2, 0, 0, 0, 7, 4, 0, 0],
        [0, 4, 9, 2, 0, 6, 0, 0, 7]
    ]
'''
def if_win(board):
    block = []
    column = []
    for row in board:
        for element in range(1,10):
            if row.count(element) != 1:                    
                return False

    for c in range (9):
        for r in range (9):
            column.append(board[r][c])
        for element in range(1,10):
            if column.count(element) != 1:                    
                return False
        column = []

    for times in range(3):
        for r in range (3):
            for c in range (3):
                block.append(board[0+3*r][c+3*times])
                block.append(board[1+3*r][c+3*times])
                block.append(board[2+3*r][c+3*times])
            for element in range(1,10):
                if block.count(element) != 1:                    
                    return False
            block = []
    return True